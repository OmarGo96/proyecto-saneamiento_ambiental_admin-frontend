# Plantilla base para proyectos Angular 19

Una breve descripción de lo que hace tu proyecto Angular y para qué sirve.

## 🧰 Tecnologías utilizadas

- [Angular](https://angular.io/) ^16+
- TypeScript
- RxJS
- Angular CLI
- [Otros paquetes importantes]

## 🚀 Instalación

1. Clona el repositorio:
   ```bash
   git clone https://github.com/usuario/nombre-proyecto.git
   cd nombre-proyecto
