# Carpeta para constantes globales
