import { Component } from '@angular/core';

@Component({
  selector: 'app-opening-by-company',
  imports: [],
  templateUrl: './opening-by-company.component.html',
  styleUrl: './opening-by-company.component.scss'
})
export class OpeningByCompanyComponent {

}
