import { Component } from '@angular/core';

@Component({
  selector: 'app-opening-statements',
  imports: [],
  templateUrl: './opening-statements.component.html',
  styleUrl: './opening-statements.component.scss'
})
export class OpeningStatementsComponent {

}
