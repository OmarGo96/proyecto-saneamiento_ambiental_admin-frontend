import { Component } from '@angular/core';

@Component({
  selector: 'app-reports-year-month',
  imports: [],
  templateUrl: './reports-year-month.component.html',
  styleUrl: './reports-year-month.component.scss'
})
export class ReportsYearMonthComponent {

}
