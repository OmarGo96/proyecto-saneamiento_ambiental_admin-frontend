import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompaniesWithoutRepresentativeComponent } from './companies-without-representative.component';

describe('CompaniesWithoutRepresentativeComponent', () => {
  let component: CompaniesWithoutRepresentativeComponent;
  let fixture: ComponentFixture<CompaniesWithoutRepresentativeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CompaniesWithoutRepresentativeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompaniesWithoutRepresentativeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
