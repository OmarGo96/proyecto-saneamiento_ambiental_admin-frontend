import { Component } from '@angular/core';

@Component({
  selector: 'app-companies-without-representative',
  imports: [],
  templateUrl: './companies-without-representative.component.html',
  styleUrl: './companies-without-representative.component.scss'
})
export class CompaniesWithoutRepresentativeComponent {

}
