import { Component } from '@angular/core';

@Component({
  selector: 'app-companies-registration',
  imports: [],
  templateUrl: './companies-registration.component.html',
  styleUrl: './companies-registration.component.scss'
})
export class CompaniesRegistrationComponent {

}
