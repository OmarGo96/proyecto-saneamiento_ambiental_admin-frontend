import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompaniesWithRepresentativeComponent } from './companies-with-representative.component';

describe('CompaniesWithRepresentativeComponent', () => {
  let component: CompaniesWithRepresentativeComponent;
  let fixture: ComponentFixture<CompaniesWithRepresentativeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CompaniesWithRepresentativeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompaniesWithRepresentativeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
