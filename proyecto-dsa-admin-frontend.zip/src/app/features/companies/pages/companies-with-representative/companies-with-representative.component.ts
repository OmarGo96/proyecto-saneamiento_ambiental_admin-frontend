import { Component } from '@angular/core';

@Component({
  selector: 'app-companies-with-representative',
  imports: [],
  templateUrl: './companies-with-representative.component.html',
  styleUrl: './companies-with-representative.component.scss'
})
export class CompaniesWithRepresentativeComponent {

}
