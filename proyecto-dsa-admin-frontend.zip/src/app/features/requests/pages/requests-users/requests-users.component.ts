import { Component } from '@angular/core';

@Component({
  selector: 'app-requests-users',
  imports: [],
  templateUrl: './requests-users.component.html',
  styleUrl: './requests-users.component.scss'
})
export class RequestsUsersComponent {

}
