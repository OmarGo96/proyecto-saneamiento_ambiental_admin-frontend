import { Component } from '@angular/core';

@Component({
  selector: 'app-requests-accepted',
  imports: [],
  templateUrl: './requests-accepted.component.html',
  styleUrl: './requests-accepted.component.scss'
})
export class RequestsAcceptedComponent {

}
