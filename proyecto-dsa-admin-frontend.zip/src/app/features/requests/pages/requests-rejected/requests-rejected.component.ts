import { Component } from '@angular/core';

@Component({
  selector: 'app-requests-rejected',
  imports: [],
  templateUrl: './requests-rejected.component.html',
  styleUrl: './requests-rejected.component.scss'
})
export class RequestsRejectedComponent {

}
