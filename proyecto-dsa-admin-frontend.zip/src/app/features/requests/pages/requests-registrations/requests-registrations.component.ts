import { Component } from '@angular/core';

@Component({
  selector: 'app-requests-registrations',
  imports: [],
  templateUrl: './requests-registrations.component.html',
  styleUrl: './requests-registrations.component.scss'
})
export class RequestsRegistrationsComponent {

}
