import { Component } from '@angular/core';

@Component({
  selector: 'app-update-users-dialog',
  imports: [],
  templateUrl: './update-users-dialog.component.html',
  styleUrl: './update-users-dialog.component.scss'
})
export class UpdateUsersDialogComponent {

}
