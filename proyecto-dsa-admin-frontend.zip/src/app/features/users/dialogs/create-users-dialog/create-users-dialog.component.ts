import { Component } from '@angular/core';

@Component({
  selector: 'app-create-users-dialog',
  imports: [],
  templateUrl: './create-users-dialog.component.html',
  styleUrl: './create-users-dialog.component.scss'
})
export class CreateUsersDialogComponent {

}
