export const environment = {
    production: false,
    urlApi: 'http://localhost/proyecto-saneamiento-backend/public/api'
};
